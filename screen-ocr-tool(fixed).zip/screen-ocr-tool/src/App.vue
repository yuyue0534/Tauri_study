<script setup lang="ts">
import { ref, onMounted } from "vue";
import Selector from "./views/Selector.vue";
import Result from "./views/Result.vue";

// 三个窗口共用同一个前端构建产物(index.html)，
// 通过 Tauri 窗口的 label 来判断当前应该渲染哪个界面：
// - "main"：托盘常驻的隐藏主窗口，不渲染任何内容
// - "selector"：全屏截图选区窗口
// - "result"：识别结果小窗口
const label = ref<string>("main");
const ready = ref(false);

onMounted(async () => {
  try {
    const { getCurrentWindow } = await import("@tauri-apps/api/window");
    label.value = getCurrentWindow().label;
  } catch (e) {
    // 非 Tauri 环境(例如纯浏览器预览)时兜底显示选区界面方便调试
    console.warn("获取窗口 label 失败，使用默认值", e);
  } finally {
    ready.value = true;
  }
});
</script>

<template>
  <div v-if="ready">
    <Selector v-if="label === 'selector'" />
    <Result v-else-if="label === 'result'" />
    <div v-else class="main-placeholder" />
  </div>
</template>

<style scoped>
.main-placeholder {
  width: 100%;
  height: 100%;
  background: transparent;
}
</style>
