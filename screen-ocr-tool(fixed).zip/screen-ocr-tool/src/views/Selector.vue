<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from "vue";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";

const imageSrc = ref<string>("");
const loadError = ref<string>("");

const dragging = ref(false);
const startX = ref(0);
const startY = ref(0);
const curX = ref(0);
const curY = ref(0);
const hasSelection = ref(false);

let unlistenRefresh: UnlistenFn | null = null;

const rectStyle = () => {
  const x = Math.min(startX.value, curX.value);
  const y = Math.min(startY.value, curY.value);
  const w = Math.abs(curX.value - startX.value);
  const h = Math.abs(curY.value - startY.value);
  return {
    left: `${x}px`,
    top: `${y}px`,
    width: `${w}px`,
    height: `${h}px`,
  };
};

const rectSize = () => {
  const w = Math.round(Math.abs(curX.value - startX.value));
  const h = Math.round(Math.abs(curY.value - startY.value));
  return `${w} x ${h}`;
};

async function loadImage() {
  loadError.value = "";
  try {
    const base64 = await invoke<string>("get_capture_image");
    imageSrc.value = `data:image/png;base64,${base64}`;
  } catch (e) {
    loadError.value = String(e);
  }
  hasSelection.value = false;
  dragging.value = false;
}

function onMouseDown(e: MouseEvent) {
  if (e.button !== 0) return;
  dragging.value = true;
  hasSelection.value = true;
  startX.value = e.clientX;
  startY.value = e.clientY;
  curX.value = e.clientX;
  curY.value = e.clientY;
}

function onMouseMove(e: MouseEvent) {
  if (!dragging.value) return;
  curX.value = e.clientX;
  curY.value = e.clientY;
}

async function onMouseUp() {
  if (!dragging.value) return;
  dragging.value = false;

  const x = Math.min(startX.value, curX.value);
  const y = Math.min(startY.value, curY.value);
  const width = Math.abs(curX.value - startX.value);
  const height = Math.abs(curY.value - startY.value);

  // 选区太小认为是误触，允许用户重新框选
  if (width < 4 || height < 4) {
    hasSelection.value = false;
    return;
  }

  try {
    await invoke("finish_capture", { x, y, width, height });
  } catch (e) {
    loadError.value = String(e);
  }
}

async function onKeydown(e: KeyboardEvent) {
  if (e.key === "Escape") {
    hasSelection.value = false;
    dragging.value = false;
    try {
      await invoke("cancel_capture");
    } catch {
      /* 忽略 */
    }
  }
}

onMounted(async () => {
  await loadImage();
  window.addEventListener("keydown", onKeydown);
  unlistenRefresh = await listen("selector-refresh", () => {
    loadImage();
  });
});

onBeforeUnmount(() => {
  window.removeEventListener("keydown", onKeydown);
  if (unlistenRefresh) unlistenRefresh();
});
</script>

<template>
  <div
    class="selector-root"
    @mousedown="onMouseDown"
    @mousemove="onMouseMove"
    @mouseup="onMouseUp"
  >
    <img v-if="imageSrc" :src="imageSrc" class="bg-image" draggable="false" />

    <div v-if="loadError" class="error-tip">加载截图失败：{{ loadError }}</div>

    <div v-if="!hasSelection && !loadError" class="hint">
      拖动鼠标框选要识别的区域，按 Esc 取消
    </div>

    <div v-if="hasSelection" class="selection-box" :style="rectStyle()">
      <div class="size-label">{{ rectSize() }}</div>
    </div>
  </div>
</template>

<style scoped>
.selector-root {
  position: relative;
  width: 100vw;
  height: 100vh;
  cursor: crosshair;
  overflow: hidden;
  background: rgba(0, 0, 0, 0.25);
}

.bg-image {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: fill;
  user-select: none;
  pointer-events: none;
}

.hint {
  position: absolute;
  top: 24px;
  left: 50%;
  transform: translateX(-50%);
  padding: 8px 18px;
  border-radius: 6px;
  background: rgba(0, 0, 0, 0.6);
  color: #fff;
  font-size: 14px;
  pointer-events: none;
  white-space: nowrap;
}

.error-tip {
  position: absolute;
  top: 24px;
  left: 50%;
  transform: translateX(-50%);
  padding: 8px 18px;
  border-radius: 6px;
  background: rgba(200, 40, 40, 0.85);
  color: #fff;
  font-size: 14px;
  pointer-events: none;
  white-space: nowrap;
}

.selection-box {
  position: absolute;
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.45);
  border: 1px solid #4a6cf7;
  pointer-events: none;
}

.size-label {
  position: absolute;
  top: -24px;
  left: 0;
  padding: 2px 8px;
  border-radius: 4px;
  background: #4a6cf7;
  color: #fff;
  font-size: 12px;
  white-space: nowrap;
}
</style>
