<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, nextTick } from "vue";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { writeText } from "@tauri-apps/plugin-clipboard-manager";

type OcrStatus = "idle" | "loading" | "done" | "error";

interface OcrResultPayload {
  status: OcrStatus;
  text: string;
  copied: boolean;
}

const status = ref<OcrStatus>("loading");
const text = ref("");
const copied = ref(false);
const copiedTip = ref(false);
const textareaRef = ref<HTMLTextAreaElement | null>(null);

let unlisten: UnlistenFn | null = null;
let tipTimer: number | undefined;

// 状态展示与“是否已复制到剪贴板”拆开，避免识别为空文本 /
// 写剪贴板失败时仍然误报“已复制”。
const statusText = computed(() => {
  if (status.value === "loading") return "正在识别…";
  if (status.value === "error") return "识别出错";
  if (status.value === "done") {
    if (!text.value) return "未识别到文字";
    if (copied.value) return "已自动复制到剪贴板 ✓";
    return "已识别，但自动复制失败，可点击下方“复制”重试";
  }
  return "";
});

const statusClass = computed(() => {
  if (status.value === "loading") return "loading";
  if (status.value === "error") return "error";
  if (status.value === "done") {
    if (!text.value) return "neutral";
    return copied.value ? "done" : "warn";
  }
  return "";
});

async function refresh() {
  try {
    const payload = await invoke<OcrResultPayload>("get_ocr_state");
    status.value = payload.status;
    text.value = payload.text;
    copied.value = payload.copied;
    if (payload.status === "done") {
      await nextTick();
      textareaRef.value?.focus();
      textareaRef.value?.select();
    }
  } catch (e) {
    status.value = "error";
    text.value = String(e);
    copied.value = false;
  }
}

async function recopy() {
  try {
    await writeText(text.value);
    copied.value = true;
    copiedTip.value = true;
    window.clearTimeout(tipTimer);
    tipTimer = window.setTimeout(() => {
      copiedTip.value = false;
    }, 1500);
  } catch (e) {
    console.error("复制失败", e);
  }
}

async function closeWindow() {
  try {
    await invoke("close_result");
  } catch {
    /* 忽略 */
  }
}

function onKeydown(e: KeyboardEvent) {
  if (e.key === "Escape") {
    closeWindow();
  }
}

onMounted(async () => {
  // 先注册事件监听，再去拉取一次当前状态：
  // 如果反过来“先 refresh 再 listen”，两次 await 之间如果 OCR 恰好完成
  // 并发出 ocr-result-updated 事件，会因为监听器还没注册而被错过，
  // 导致界面卡在 loading，即使后端其实已经 done。
  unlisten = await listen("ocr-result-updated", () => {
    refresh();
  });
  window.addEventListener("keydown", onKeydown);
  await refresh();
});

onBeforeUnmount(() => {
  if (unlisten) unlisten();
  window.removeEventListener("keydown", onKeydown);
  window.clearTimeout(tipTimer);
});
</script>

<template>
  <div class="result-root">
    <div class="header">
      <span class="title">识别结果</span>
      <span class="status" :class="statusClass">{{ statusText }}</span>
    </div>

    <textarea
      ref="textareaRef"
      v-model="text"
      class="text-area"
      :placeholder="status === 'loading' ? '正在识别文字，请稍候…' : '未识别到文字'"
      spellcheck="false"
    ></textarea>

    <div class="footer">
      <span v-if="copiedTip" class="copied-tip">已复制</span>
      <button class="btn secondary" @click="closeWindow">关闭 (Esc)</button>
      <button class="btn primary" :disabled="!text" @click="recopy">
        复制
      </button>
    </div>
  </div>
</template>

<style scoped>
.result-root {
  display: flex;
  flex-direction: column;
  width: 100vw;
  height: 100vh;
  padding: 14px;
  background: #ffffff;
  color: #222;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
  gap: 10px;
}

.title {
  font-size: 15px;
  font-weight: 600;
  flex-shrink: 0;
}

.status {
  font-size: 12px;
  color: #888;
  text-align: right;
}
.status.loading {
  color: #4a6cf7;
}
.status.done {
  color: #16a34a;
}
.status.warn {
  color: #d97706;
}
.status.neutral {
  color: #888;
}
.status.error {
  color: #dc2626;
}

.text-area {
  flex: 1;
  width: 100%;
  resize: none;
  padding: 10px;
  font-size: 14px;
  line-height: 1.5;
  border: 1px solid #e2e2e2;
  border-radius: 6px;
  outline: none;
  font-family: inherit;
}
.text-area:focus {
  border-color: #4a6cf7;
}

.footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 10px;
}

.copied-tip {
  margin-right: auto;
  font-size: 12px;
  color: #16a34a;
}

.btn {
  padding: 6px 16px;
  border-radius: 6px;
  border: 1px solid transparent;
  font-size: 13px;
  cursor: pointer;
}

.btn.secondary {
  background: #f3f4f6;
  color: #333;
  border-color: #e2e2e2;
}
.btn.secondary:hover {
  background: #e9e9eb;
}

.btn.primary {
  background: #4a6cf7;
  color: #fff;
}
.btn.primary:hover {
  background: #3a5ce0;
}
.btn.primary:disabled {
  background: #b7c3f7;
  cursor: not-allowed;
}
</style>
