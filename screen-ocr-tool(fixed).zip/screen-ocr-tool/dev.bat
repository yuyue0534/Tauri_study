@echo off
chcp 65001 >nul
echo ============================================
echo  安装依赖并以开发模式启动 (首次运行会编译较久)
echo ============================================
call npm install
if errorlevel 1 (
    echo npm install 失败，请检查上方报错信息
    pause
    exit /b 1
)
call npm run tauri dev
pause
