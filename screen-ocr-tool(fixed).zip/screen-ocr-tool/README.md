# 截图识别小工具（Tauri 2 + Vue 3 + TS）

托盘常驻 → 快捷键截图 → 鼠标框选 → 本地 OCR 识别 → 自动复制到剪贴板，
并可在弹出的小窗口中查看/编辑识别结果。

## v2 更新（基于代码审计的修复）

相比 v1，这一版修了几个经审计发现、影响首次真机运行体验的问题：

- **窗口改为启动阶段预创建**：`selector` / `result` 两个窗口现在都在 `setup()`（主线程）
  阶段一次性创建好并隐藏，运行时只做 `show/hide/set_position/set_size`，不再在快捷键
  回调、托盘菜单事件、同步命令里动态 `build()` 窗口——规避 Tauri 在 Windows 上“非主线程/
  同步上下文动态建窗口可能卡死”的已知风险类别。
- **全局快捷键注册失败不再让整个程序崩溃**：如果 `Ctrl+Alt+S` 被其他软件占用，之前会导致
  连托盘图标都出不来；现在会打日志、应用照常启动，可通过托盘菜单手动截图。
- **截图前会先隐藏自己的窗口**：避免连续多次截图时，把上一次还没关掉的选区遮罩/结果小窗
  自身截进新的截图里。
- **Result 窗口先监听事件、再拉取状态**：避免“OCR 恰好在监听器注册前完成”导致界面卡在
  “正在识别”不刷新的理论竞态。
- **拆分“识别状态”与“是否已复制到剪贴板”**：识别到空文本、或写剪贴板失败时，不会再
  被误报成“已自动复制到剪贴板 ✓”。
- 一处 Mutex 加锁代码改成显式绑定守卫变量再 `clone()`，写法更直白（原写法在我们看来本身
  没有编译问题，这里只是消除阅读上的歧义）。

## 技术方案

| 模块 | 方案 |
|---|---|
| 应用框架 | Tauri 2 + Vue 3 + TypeScript |
| 托盘 & 菜单 | Tauri `tray-icon` |
| 全局快捷键 | `tauri-plugin-global-shortcut`（默认 `Ctrl+Alt+S`） |
| 截屏 | Rust `xcap`（自动定位鼠标所在显示器并截取整屏） |
| 框选交互 | Vue 全屏透明无边框窗口 + CSS `box-shadow` 挖空高亮 |
| OCR | Rust `win_ocr`，底层调用 **Windows 系统自带**的 `Windows.Media.Ocr`，全程本地识别、不联网 |
| 剪贴板 | `tauri-plugin-clipboard-manager` |
| 结果编辑 | 独立小窗口（可编辑 + 重新复制） |

因为 OCR 直接复用 Windows 系统能力，应用本身**不随包内置任何 OCR 引擎或语言模型**，
安装包因此很小；但这不等于“开箱即用不用装任何东西”——识别效果依赖**系统已经安装了
对应语言的 OCR 组件**（见下文“环境准备”第 5 条），没装的话识别会直接报错。
本工具也**只能在 Windows 10 1903+ / Windows 11 上运行**。

## 目录结构

```
screen-ocr-tool/
├── src/                     # Vue 前端
│   ├── main.ts
│   ├── App.vue              # 按窗口 label 分发到 Selector / Result
│   ├── style.css
│   └── views/
│       ├── Selector.vue     # 全屏截图选区
│       └── Result.vue       # 识别结果小窗口
├── src-tauri/               # Rust 后端
│   ├── src/
│   │   ├── main.rs
│   │   ├── lib.rs           # 注册插件、快捷键、托盘、Tauri 命令
│   │   ├── capture.rs       # 截图 / 裁剪 / 窗口管理 / 各 Tauri 命令
│   │   ├── ocr.rs           # 本地 OCR 封装
│   │   └── state.rs         # 全局状态（截图缓存 + 识别结果）
│   ├── capabilities/default.json
│   ├── icons/
│   ├── tauri.conf.json
│   └── Cargo.toml
├── package.json
└── vite.config.ts
```

## 环境准备（首次使用必看）

1. **Node.js**：18 及以上版本，https://nodejs.org
2. **Rust**：通过 https://rustup.rs 安装（选默认选项即可），装完重启终端。
3. **C++ 编译工具链（Windows 编译 Rust 必需）**：
   安装 [Visual Studio 2022 Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)，
   勾选“使用 C++ 的桌面开发（Desktop development with C++）”工作负载。
4. **WebView2 运行时**：Windows 11 通常已自带，无需额外安装；
   如果启动报错提示缺少 WebView2，去
   https://developer.microsoft.com/microsoft-edge/webview2/ 下载安装。
5. **Windows OCR 语言包（重要）**：
   打开 `设置 → 时间和语言 → 语言和区域 → 添加语言`，
   添加“中文（简体，中国）”（如果只识别英文可以跳过，装英文包即可），
   安装完成后点开该语言，展开“语言选项”，确认勾选/安装了
   **“光学字符识别”**（Optical character recognition）组件。
   —— 这是 Windows 系统自带 OCR 能否工作的关键，很多“识别不出文字”的问题都是因为没装这个。

## 安装依赖

在项目根目录（本文件所在目录）执行：

```bash
npm install
```

## 开发模式运行（推荐先用这个验证效果）

```bash
npm run tauri dev
```

第一次执行会编译 Rust 依赖，耗时较久（几分钟），请耐心等待。
成功后程序会常驻在系统托盘（任务栏右下角小箭头里），没有主窗口弹出，这是正常的。

## 打包为可直接双击运行的安装包

```bash
npm run tauri build
```

构建完成后，安装包位于：

```
src-tauri/target/release/bundle/nsis/screen-ocr-tool_0.1.0_x64-setup.exe
```

也可以直接运行免安装的可执行文件（同样需要该机器已装好 WebView2 运行时）：

```
src-tauri/target/release/screen-ocr-tool.exe
```

## 使用方法

1. 启动后程序常驻在系统托盘（无主窗口），托盘图标可右键查看菜单。
2. 按下快捷键 `Ctrl + Alt + S`（或托盘菜单里点“截图识别”）。
3. 屏幕（鼠标所在的那个显示器）会被冻结显示，此时按住鼠标左键拖动框选目标区域，松开鼠标即可。
   - 按 `Esc` 可取消本次截图。
4. 松开鼠标后会自动裁剪、本地 OCR 识别，识别文字会**自动写入剪贴板**，
   同时弹出一个小窗口展示识别结果。
5. 小窗口里的文字可以直接编辑；改完点“复制”按钮可重新复制修改后的内容；
   点“关闭”或按 `Esc` 关闭小窗口。

## 常见问题

- **识别不出文字 / 报错提示要装语言包**：
  按上文“Windows OCR 语言包”一节安装对应语言的“光学字符识别”组件后重启程序。
- **多显示器**：v1 版本会根据“按快捷键时鼠标所在的显示器”来截图，
  暂不支持一次框选跨越多个显示器。
- **修改快捷键**：编辑 `src-tauri/src/lib.rs` 中这一行：
  ```rust
  let shortcut = Shortcut::new(Some(Modifiers::CONTROL | Modifiers::ALT), Code::KeyS);
  ```
  改成你想要的组合键后重新 `npm run tauri dev` / `build`。
- **运行时报 "xxx not allowed / missing permission" 之类的错误**：
  这是 Tauri 2 的权限系统（capabilities）拦截了某个调用，控制台错误信息会
  明确指出缺哪个 permission 字符串，把它加进
  `src-tauri/capabilities/default.json` 的 `permissions` 数组里即可。
- **杀毒软件报警 / SmartScreen 拦截**：属于未签名的自编译小工具的常见现象，
  选择“仍要运行”即可；如需分发给他人使用，建议后续对安装包做代码签名。

## 后续可扩展方向（v1 未实现）

- 识别历史记录、多语言可选（当前默认优先中文，自动回退系统默认语言）
- 截图标注/画笔
- 自定义/多组快捷键、开机自启开关（可加 `tauri-plugin-autostart`）
- 跨平台 OCR（macOS/Linux 需要换用 tesseract 等其它引擎，当前实现仅支持 Windows）
