use tauri::{
    menu::{Menu, MenuItem, PredefinedMenuItem},
    tray::TrayIconBuilder,
    AppHandle, Manager,
};

use crate::capture::trigger_capture;

pub fn setup_tray(app: &AppHandle) -> tauri::Result<()> {
    let capture_item = MenuItem::with_id(app, "capture", "截图识别 (Ctrl+Alt+S)", true, None::<&str>)?;
    let separator = PredefinedMenuItem::separator(app)?;
    let quit_item = MenuItem::with_id(app, "quit", "退出", true, None::<&str>)?;

    let menu = Menu::with_items(app, &[&capture_item, &separator, &quit_item])?;

    let icon = app
        .default_window_icon()
        .cloned()
        .expect("应用图标未配置，请检查 tauri.conf.json 中的 bundle.icon");

    TrayIconBuilder::with_id("main-tray")
        .icon(icon)
        .tooltip("截图识别小工具 (Ctrl+Alt+S 截图)")
        .menu(&menu)
        .show_menu_on_left_click(true)
        .on_menu_event(|app, event| match event.id.as_ref() {
            "capture" => trigger_capture(app),
            "quit" => app.exit(0),
            _ => {}
        })
        .build(app)?;

    Ok(())
}
