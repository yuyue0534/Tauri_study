/// 对给定路径的 PNG 图片执行本地 OCR 识别，返回识别到的文本。
///
/// 使用 win_ocr crate，其底层调用 Windows 系统自带的
/// `Windows.Media.Ocr` API（UWP OCR 引擎），无需联网、无需额外安装
/// 任何可执行文件，但需要系统安装了对应语言的 “光学字符识别” 语言包。
///
/// 识别策略：
/// 1. 优先尝试简体中文(zh-Hans)，因为该工具的主要使用场景是中文内容。
/// 2. 如果系统没有安装中文 OCR 语言包（zh-Hans 初始化失败），
///    自动回退到系统当前可用的第一种语言（通常是英文）。
pub fn recognize(path: &str) -> Result<String, String> {
    match win_ocr::ocr_with_lang(path, "zh-Hans") {
        Ok(text) => Ok(text),
        Err(_) => win_ocr::ocr(path).map_err(|e| {
            format!(
                "OCR 识别失败：{:?}。请确认 Windows 已安装 OCR 语言包 \
                （设置 → 时间和语言 → 语言和区域 → 添加语言，并在语言的\
                “可选功能”中勾选“光学字符识别”）。",
                e
            )
        }),
    }
}
