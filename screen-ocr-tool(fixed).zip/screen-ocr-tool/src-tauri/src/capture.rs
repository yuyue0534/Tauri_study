use base64::{engine::general_purpose, Engine as _};
use mouse_position::mouse_position::Mouse;
use serde::Serialize;
use tauri::{AppHandle, Emitter, Manager, PhysicalPosition, PhysicalSize, WebviewUrl, WebviewWindowBuilder};
use tauri_plugin_clipboard_manager::ClipboardExt;
use xcap::Monitor;

use crate::ocr;
use crate::state::{AppState, CaptureData};

/// 应用启动阶段（setup，运行在主线程）预先创建好 selector / result 两个窗口并隐藏。
///
/// 这样做是为了避免在“全局快捷键回调”“托盘菜单事件”“同步 Tauri 命令”这些
/// 不一定运行在主线程 / 不一定适合阻塞等待的上下文里动态调用
/// `WebviewWindowBuilder::build()`——Tauri 在 Windows 上对“运行时动态创建 WebView
/// 窗口”有已知的潜在卡死风险。预创建之后，后续所有触发截图/展示结果的路径
/// 都只对已经存在的窗口做 show / hide / set_position / set_size，不再调用 build()。
pub fn create_app_windows(app: &AppHandle) -> tauri::Result<()> {
    WebviewWindowBuilder::new(app, "selector", WebviewUrl::App("index.html".into()))
        .title("截图选区")
        .decorations(false)
        .transparent(true)
        .always_on_top(true)
        .skip_taskbar(true)
        .resizable(false)
        .shadow(false)
        .visible(false)
        .inner_size(800.0, 600.0)
        .build()?;

    WebviewWindowBuilder::new(app, "result", WebviewUrl::App("index.html".into()))
        .title("识别结果")
        .inner_size(440.0, 380.0)
        .min_inner_size(320.0, 260.0)
        .resizable(true)
        .decorations(true)
        .visible(false)
        .center()
        .build()?;

    Ok(())
}

/// 由全局快捷键 / 托盘菜单触发：
/// 1. 先隐藏本应用自己可能还显示着的 selector / result 窗口，避免把上一次的
///    选区遮罩、结果小窗自身截进新的截图里
/// 2. 找到鼠标当前所在的显示器
/// 3. 截取该显示器的整屏画面，存入应用状态
/// 4. 展示一个覆盖该显示器的无边框选区窗口，供用户框选区域
pub fn trigger_capture(app: &AppHandle) {
    let mut needs_settle = false;
    if let Some(win) = app.get_webview_window("selector") {
        if win.is_visible().unwrap_or(false) {
            needs_settle = true;
        }
        let _ = win.hide();
    }
    if let Some(win) = app.get_webview_window("result") {
        if win.is_visible().unwrap_or(false) {
            needs_settle = true;
        }
        let _ = win.hide();
    }
    if needs_settle {
        // 给窗口隐藏动作一点时间真正从屏幕上消失，再截图，
        // 避免把刚关闭的遮罩/结果窗残影截进去。这是一个尽力而为的经验值，
        // 不是严格保证；极端情况下（系统卡顿）仍可能残留。
        std::thread::sleep(std::time::Duration::from_millis(60));
    }

    let (mouse_x, mouse_y) = match Mouse::get_mouse_position() {
        Mouse::Position { x, y } => (x, y),
        Mouse::Error => (0, 0),
    };

    let monitor = match Monitor::from_point(mouse_x, mouse_y) {
        Ok(m) => m,
        Err(_) => match Monitor::all().ok().and_then(|list| list.into_iter().next()) {
            Some(m) => m,
            None => {
                eprintln!("[screen-ocr-tool] 未找到任何显示器，无法截图");
                return;
            }
        },
    };

    let image = match monitor.capture_image() {
        Ok(img) => img,
        Err(e) => {
            eprintln!("[screen-ocr-tool] 截图失败: {e}");
            return;
        }
    };

    let scale_factor = monitor.scale_factor().unwrap_or(1.0) as f64;
    let mon_x = monitor.x().unwrap_or(0);
    let mon_y = monitor.y().unwrap_or(0);
    let width = image.width();
    let height = image.height();

    {
        let state = app.state::<AppState>();
        *state.capture.lock().unwrap() = Some(CaptureData {
            image,
            scale_factor,
        });
        let mut ocr = state.ocr.lock().unwrap();
        ocr.status = "idle".to_string();
        ocr.text.clear();
        ocr.copied = false;
    }

    show_selector_window(app, mon_x, mon_y, width, height);
}

/// 只对启动阶段已经预创建好的 selector 窗口做定位 / 尺寸调整 / 显示，
/// 不在这里动态 build 新窗口（见 create_app_windows 上的说明）。
fn show_selector_window(app: &AppHandle, x: i32, y: i32, width: u32, height: u32) {
    let Some(win) = app.get_webview_window("selector") else {
        eprintln!("[screen-ocr-tool] 选区窗口不存在（应用启动阶段可能创建失败）");
        return;
    };
    let _ = win.set_position(PhysicalPosition::new(x, y));
    let _ = win.set_size(PhysicalSize::new(width, height));
    let _ = win.show();
    let _ = win.set_focus();
    let _ = win.emit("selector-refresh", ());
}

/// 同上，只对预创建好的 result 窗口做显示 / 聚焦。
fn show_result_window(app: &AppHandle) {
    let Some(win) = app.get_webview_window("result") else {
        eprintln!("[screen-ocr-tool] 结果窗口不存在（应用启动阶段可能创建失败）");
        return;
    };
    let _ = win.show();
    let _ = win.unminimize();
    let _ = win.set_focus();
}

#[derive(Serialize)]
pub struct OcrResultPayload {
    pub status: String,
    pub text: String,
    pub copied: bool,
}

/// 前端在选区窗口挂载后调用，拉取当前截图的 base64 PNG 数据用于展示。
#[tauri::command]
pub fn get_capture_image(app: AppHandle) -> Result<String, String> {
    let state = app.state::<AppState>();
    let guard = state.capture.lock().unwrap();
    let data = guard.as_ref().ok_or_else(|| "没有可用的截图数据".to_string())?;

    let mut buf: Vec<u8> = Vec::new();
    data.image
        .write_to(&mut std::io::Cursor::new(&mut buf), image::ImageFormat::Png)
        .map_err(|e| format!("图片编码失败: {e}"))?;

    Ok(general_purpose::STANDARD.encode(buf))
}

/// 前端在选区窗口鼠标松开、确定选区后调用。
/// x/y/width/height 为“逻辑像素”，与窗口 CSS 视口坐标一致，
/// 这里会结合显示器缩放比例换算为图像的物理像素坐标后裁剪。
#[tauri::command]
pub fn finish_capture(app: AppHandle, x: f64, y: f64, width: f64, height: f64) -> Result<(), String> {
    if let Some(win) = app.get_webview_window("selector") {
        let _ = win.hide();
    }

    // 显式绑定锁守卫再 clone，尽快释放锁，同时让生命周期一目了然。
    let capture_data = {
        let state = app.state::<AppState>();
        let guard = state.capture.lock().unwrap();
        guard.clone()
    };
    let capture_data = capture_data.ok_or_else(|| "未捕获到屏幕画面".to_string())?;

    let scale = capture_data.scale_factor;
    let img_w = capture_data.image.width() as f64;
    let img_h = capture_data.image.height() as f64;

    let px_x = (x * scale).max(0.0);
    let px_y = (y * scale).max(0.0);
    let px_w = (width * scale).min((img_w - px_x).max(0.0));
    let px_h = (height * scale).min((img_h - px_y).max(0.0));

    if px_w < 2.0 || px_h < 2.0 {
        return Err("选区过小".to_string());
    }

    {
        let state = app.state::<AppState>();
        let mut ocr = state.ocr.lock().unwrap();
        ocr.status = "loading".to_string();
        ocr.text.clear();
        ocr.copied = false;
    }

    show_result_window(&app);
    let _ = app.emit("ocr-result-updated", ());

    let app_clone = app.clone();
    std::thread::spawn(move || {
        let cropped = image::imageops::crop_imm(
            &capture_data.image,
            px_x.round() as u32,
            px_y.round() as u32,
            px_w.round() as u32,
            px_h.round() as u32,
        )
        .to_image();

        let tmp_path = std::env::temp_dir().join(format!(
            "screen_ocr_tool_{}_{}.png",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_millis())
                .unwrap_or(0)
        ));

        let ocr_outcome = match cropped.save(&tmp_path) {
            Ok(_) => ocr::recognize(&tmp_path.to_string_lossy()),
            Err(e) => Err(format!("保存临时截图失败: {e}")),
        };
        let _ = std::fs::remove_file(&tmp_path);

        let state = app_clone.state::<AppState>();
        match ocr_outcome {
            Ok(text) => {
                let trimmed = text.trim().to_string();
                let mut copied = false;
                if !trimmed.is_empty() {
                    match app_clone.clipboard().write_text(trimmed.clone()) {
                        Ok(_) => copied = true,
                        Err(e) => eprintln!("[screen-ocr-tool] 写入剪贴板失败: {e}"),
                    }
                }
                let mut ocr = state.ocr.lock().unwrap();
                ocr.status = "done".to_string();
                ocr.text = trimmed;
                ocr.copied = copied;
            }
            Err(e) => {
                let mut ocr = state.ocr.lock().unwrap();
                ocr.status = "error".to_string();
                ocr.text = e;
                ocr.copied = false;
            }
        }
        drop(state);
        let _ = app_clone.emit("ocr-result-updated", ());
    });

    Ok(())
}

/// 用户按 Esc 取消本次框选
#[tauri::command]
pub fn cancel_capture(app: AppHandle) {
    if let Some(win) = app.get_webview_window("selector") {
        let _ = win.hide();
    }
}

/// 结果窗口挂载 / 收到刷新事件时调用，拉取最新的识别状态与文本
#[tauri::command]
pub fn get_ocr_state(app: AppHandle) -> OcrResultPayload {
    let state = app.state::<AppState>();
    let ocr = state.ocr.lock().unwrap();
    OcrResultPayload {
        status: ocr.status.clone(),
        text: ocr.text.clone(),
        copied: ocr.copied,
    }
}

/// 关闭结果窗口（隐藏，下次复用，避免重复创建的开销）
#[tauri::command]
pub fn close_result(app: AppHandle) {
    if let Some(win) = app.get_webview_window("result") {
        let _ = win.hide();
    }
}
