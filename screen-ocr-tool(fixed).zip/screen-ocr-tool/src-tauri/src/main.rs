// 防止在 Windows Release 构建下弹出多余的控制台窗口
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    screen_ocr_tool_lib::run();
}
