mod capture;
mod ocr;
mod state;
mod tray;

use tauri::WindowEvent;
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Modifiers, Shortcut, ShortcutState};

use capture::trigger_capture;
use state::AppState;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(AppState::default())
        .plugin(tauri_plugin_clipboard_manager::init())
        .invoke_handler(tauri::generate_handler![
            capture::get_capture_image,
            capture::finish_capture,
            capture::cancel_capture,
            capture::get_ocr_state,
            capture::close_result,
        ])
        .on_window_event(|window, event| {
            // 选区窗口 / 结果窗口被用户点了关闭按钮时，只隐藏不销毁，
            // 方便下次截图时复用窗口，减少重新创建的开销。
            if let WindowEvent::CloseRequested { api, .. } = event {
                let label = window.label();
                if label == "selector" || label == "result" {
                    let _ = window.hide();
                    api.prevent_close();
                }
            }
        })
        .setup(|app| {
            let handle = app.handle().clone();

            // 预先创建好 selector / result 两个窗口并隐藏（见 capture.rs 中的说明），
            // setup 明确运行在主线程，这是创建窗口最安全的时机。
            capture::create_app_windows(&handle)?;

            // 默认快捷键：Ctrl + Alt + S，可按需修改下方的 Modifiers / Code。
            let shortcut = Shortcut::new(Some(Modifiers::CONTROL | Modifiers::ALT), Code::KeyS);
            let shortcut_for_handler = shortcut.clone();

            app.handle().plugin(
                tauri_plugin_global_shortcut::Builder::new()
                    .with_handler(move |app, pressed_shortcut, event| {
                        if pressed_shortcut == &shortcut_for_handler
                            && event.state == ShortcutState::Pressed
                        {
                            trigger_capture(app);
                        }
                    })
                    .build(),
            )?;

            // 快捷键有可能被其他程序占用（register 返回 Err）。这里刻意不用 `?`
            // 直接向上传播 —— 一旦传播，setup 整体失败，run(...).expect(...) 会让
            // 整个应用（包括托盘图标）直接崩溃退出，新用户很容易第一次启动就
            // "什么都没发生"。因此改为仅记录日志，托盘依然正常显示，用户还可以
            // 通过托盘菜单里的"截图识别"手动触发，并按 README 提示更换快捷键。
            if let Err(e) = app.global_shortcut().register(shortcut) {
                eprintln!(
                    "[screen-ocr-tool] 全局快捷键 Ctrl+Alt+S 注册失败（可能已被其他程序占用）：{e}\n\
                     应用会继续正常启动，可通过托盘菜单里的“截图识别”手动截图，\
                     或修改 src-tauri/src/lib.rs 中的快捷键组合后重新编译。"
                );
            }

            tray::setup_tray(&handle)?;

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
