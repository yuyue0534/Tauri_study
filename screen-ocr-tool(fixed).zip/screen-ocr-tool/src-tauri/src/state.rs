use image::RgbaImage;
use serde::Serialize;
use std::sync::Mutex;

/// 一次截图捕获到的原始图像数据及其所在显示器的缩放比例。
/// scale_factor 用于把前端传回的“逻辑像素”选区换算成图像本身的“物理像素”坐标。
#[derive(Clone)]
pub struct CaptureData {
    pub image: RgbaImage,
    pub scale_factor: f64,
}

#[derive(Clone, Serialize)]
pub struct OcrResult {
    /// idle | loading | done | error
    pub status: String,
    pub text: String,
    /// 是否已经成功写入剪贴板。区分“识别到空文本”“写剪贴板失败”这两种
    /// 不应该显示“已复制”的情况，避免 UI 误报复制成功。
    pub copied: bool,
}

impl Default for OcrResult {
    fn default() -> Self {
        Self {
            status: "idle".to_string(),
            text: String::new(),
            copied: false,
        }
    }
}

#[derive(Default)]
pub struct AppState {
    pub capture: Mutex<Option<CaptureData>>,
    pub ocr: Mutex<OcrResult>,
}
