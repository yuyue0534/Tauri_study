import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";

// Tauri 官方推荐的 Vite 配置：固定端口、忽略 src-tauri 目录变更等
const host = process.env.TAURI_DEV_HOST;

export default defineConfig({
  plugins: [vue()],
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: host || false,
    hmr: host
      ? {
          protocol: "ws",
          host,
          port: 1421,
        }
      : undefined,
    watch: {
      ignored: ["**/src-tauri/**"],
    },
  },
});
