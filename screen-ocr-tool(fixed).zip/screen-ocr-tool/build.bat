@echo off
chcp 65001 >nul
echo ============================================
echo  安装依赖并打包生成可安装的 exe
echo ============================================
call npm install
if errorlevel 1 (
    echo npm install 失败，请检查上方报错信息
    pause
    exit /b 1
)
call npm run tauri build
if errorlevel 1 (
    echo 打包失败，请检查上方报错信息
    pause
    exit /b 1
)
echo.
echo 打包完成！安装包位于:
echo   src-tauri\target\release\bundle\nsis\
echo 免安装可执行文件位于:
echo   src-tauri\target\release\screen-ocr-tool.exe
pause
